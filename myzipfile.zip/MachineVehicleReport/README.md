# MachineVehicleReport

### Steps to run :
> - just run the `server.py` file by running the following command
> ```
>  python3 server.py
> ```
